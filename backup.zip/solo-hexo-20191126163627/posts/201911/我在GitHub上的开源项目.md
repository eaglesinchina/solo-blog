title: 我在 GitHub 上的开源项目
date: '2019-11-23 16:17:57'
updated: '2019-11-23 16:17:57'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [spark](https://github.com/eaglesinchina/spark) <kbd title="主要编程语言">Scala</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/eaglesinchina/spark/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/eaglesinchina/spark/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/eaglesinchina/spark/network/members "分叉数")</span>





---

### 2. [hadoop](https://github.com/eaglesinchina/hadoop) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/eaglesinchina/hadoop/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/eaglesinchina/hadoop/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/eaglesinchina/hadoop/network/members "分叉数")</span>

hdfs,mr, hive,haase,spark...基本测试



---

### 3. [ssm_productMS](https://github.com/eaglesinchina/ssm_productMS) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/eaglesinchina/ssm_productMS/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/eaglesinchina/ssm_productMS/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/eaglesinchina/ssm_productMS/network/members "分叉数")</span>

java swing, nio, ssm网页

